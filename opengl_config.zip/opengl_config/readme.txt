copy all the .dll files in dll folder to c:/windows/system32

copy all the .h files in gl folder to vc/include/gl (if no gl folder, create a folder named gl)

copy all the .lib files to vc/lib 